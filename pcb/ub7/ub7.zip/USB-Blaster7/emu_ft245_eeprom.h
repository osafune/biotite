//This is include file for FT245EEPROM Emulation
#ifndef EMU_FT245_EEPROM_H
#define EMU_FT245_EEPROM_H
BYTE eeprom_read(BYTE adr);
void eeprom_init(void);
#endif
